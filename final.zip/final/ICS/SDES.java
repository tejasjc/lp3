import java.util.*;

public class SDES {
	
	static Scanner sc=new Scanner(System.in);
	static int key[]={1,0,1,0,0,0,0,0,1,0};
	int[] p_10={2,4,1,6,3,9,0,8,7,5};
	int p_8[]={5,2,6,3,7,4,9,8};
	int IP_8[]={1,5,2,0,3,7,4,6};
	int EP[]={3,0,1,2,1,2,3,0};
	int IP_1[]={3,0,2,4,6,1,7,5};
	static int S0[][]={{01,00,11,10},{11,10,01,00},{00,10,01,11},{11,01,11,10}};
	static int S1[][]={{00,01,10,11},{10,00,01,11},{11,00,01,00},{10,01,00,11}};
	static int temp_p10[]=new int[10];
	static int plain_Text[]={0,1,1,1,0,0,1,0};
	static int p4[]={1,3,2,0};
	static int temp_p8[]=new int[10];
	static int key1[]=new int[8];
	static int key2[]=new int[8];
	static int flag=0;
	static int inter[]=new int[8];
	
	/*public void getKey(){
		System.out.println("Enter the key: ");
		for(int i=0;i<10;i++){
			key[i]=sc.nextInt();
		}
	}*/
	
	public int[] bit_convert(Integer[] a){
		String a1=Integer.toString(a[0])+Integer.toString(a[3]); // We are doing this to select number from particular column & row.
		String a2=Integer.toString(a[1])+Integer.toString(a[2]);
		int a3[]=new int[2];
		a3[0]=Integer.parseInt(a1,2); // This function is used to convert from binary to decimal. 
		a3[1]=Integer.parseInt(a2,2);
		return a3;
	}
	
	public int[] roundShift(int n,int a[]){
		Integer a1[]=new Integer[5];
		Integer a2[]=new Integer[5];
		for(int i=0;i<5;i++){ // Dividing into two halfs.
			a1[i]=a[i];   
			a2[i]=a[i+5];
		}
		Collections.rotate(Arrays.asList(a1),n);
		Collections.rotate(Arrays.asList(a2),n);
		for(int i=0;i<5;i++){
			a[i]=a1[i];
			a[i+5]=a2[i];
		}
		return a;
	}
	
	public void key1Genration(int key[]){
		for(int i=0;i<10;i++){
			temp_p10[i]=key[p_10[i]]; //applying P10 table.
		}
		temp_p10=roundShift(-1,temp_p10); //shifting by 1 bit towards left.
		for(int i=0;i<10;i++){
			if(i==8)
				break;// since the key1 array size is 8 and we are avoiding extra declarations.
			key1[i]=temp_p10[p_8[i]];
		}
	}
	
	public void key2Genration(int key[]){ //this is completly same code as key1 genration just we are shifting extra bits.
		for(int i=0;i<10;i++){
			temp_p10[i]=key[p_10[i]];
		}
		temp_p10=roundShift(-3,temp_p10);
		for(int i=0;i<10;i++){
			if(i==8)
				break;
			key2[i]=temp_p10[p_8[i]];
		}
	}
	
	public int[] IP8genrate(int ptext[]){
		for(int i=0;i<8;i++){
			temp_p8[i]=ptext[IP_8[i]]; //applying the IP8 table.
		}
		return temp_p8;
	}
	
	public void encryption(int ptext[],int key[]){
		if(flag==0){
			temp_p8=IP8genrate(ptext);  // We have taken flag here as we need to apply IP8 only once for key1 not for key2.
		}
		/*for(int i=0;i<8;i++){
			//temp_p8[i]=a1[EP[i]];
			System.out.print(temp_p8[i]);
		}*/
		Integer a1[]=new Integer[4];
		Integer a2[]=new Integer[4];
		for(int i=0,j=4;i<4;i++,j++){
			a1[i]=temp_p8[i];    // Dividing into two halfs.
			a2[i]=temp_p8[j];
		}
		int left_half[]=new int[4]; 
		int right_half[]=new int[4];
		for(int i=0;i<4;i++){
			left_half[i]=a1[i];    // We are storing this two halfs as we need this in the later stage of our program while a1 & a2 will be overrided.
			right_half[i]=a2[i];
		}
		for(int i=0;i<8;i++){
			temp_p8[i]=a2[EP[i]];   // Applying EP table.
		}
		for(int i=0;i<8;i++){
			temp_p8[i]=temp_p8[i]^key[i]; // Performing XOR operation with the key.
		}
		for(int i=0,j=4;i<4;i++,j++){
			a1[i]=temp_p8[i];	// Again dividing into two halfs.
			a2[i]=temp_p8[j];
		}
		int a3[]=bit_convert(a1);
		int a4[]=bit_convert(a2);
		StringBuffer s=new StringBuffer();  // We will using append function which is not in String class hence use StringBuffer.
		s.append(String.valueOf(S0[a3[0]][a3[1]])); 
		s.append(String.valueOf(S1[a4[0]][a4[1]]));
		for(int i=0;i<4;i++){
			a2[i]=(int) s.charAt(p4[i]);
			if(a2[i]==48)
				a2[i]=0;
			else
				a2[i]=1;
		}
		for(int i=0;i<4;i++){
			a2[i]=a2[i]^left_half[i];
		}
		for(int i=0,j=4;i<4;i++,j++){
			temp_p8[i]=a2[i];
			temp_p8[j]=right_half[i];
		}
		for(int i=0;i<8;i++){
			System.out.print(temp_p8[i]);
		}
		if(flag==0){
		inter=swapHalfLast(temp_p8);
		System.out.println();
		for(int i=0;i<8;i++){
			System.out.print(inter[i]);
		}
		flag++;
		}
		else if(flag==1){
			applyIP_1(temp_p8);
		}
		else
			System.out.println("Something is wrong...");
		}
	
	public void applyIP_1(int temp[]){
		int tt[]=new int[8];
		System.out.println("The Final Cipher is: ");
		for(int i=0;i<8;i++){
			tt[i]=temp[IP_1[i]];
			System.out.print(tt[i]);
		}
	}
	
	public int[] swapHalfLast(int a[]){
		Integer a1[]=new Integer[4];
		Integer a2[]=new Integer[4];
		int k=4;
		for(int i=0,j=4;i<4;i++,j++){
			a1[i]=a[i];
			a2[i]=a[j];
		}
		for(int i=0,j=0;i<4;i++,j++){
			a[i]=a2[i];
			a[k]=a1[j];
			k++;
		}
		return a;
	}

	public static void main(String[] args) {
		SDES s=new SDES();
		//s.getKey();
		s.key1Genration(key);
		s.key2Genration(key);
		s.encryption(plain_Text,key1);
		s.encryption(inter,key2);
	}
}
