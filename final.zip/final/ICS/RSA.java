package prac;
import java.math.BigInteger;
import java.util.Random;
import java.util.Scanner;

public class RSA {

	BigInteger p, q, phi, n, e, d;
	int bitlen = 1024;
	Random r;

	RSA() {
		r = new Random();
		p = BigInteger.probablePrime(bitlen, r);
		q = BigInteger.probablePrime(bitlen, r);
		n = p.multiply(q);
		phi = p.subtract(BigInteger.ONE).multiply(q.subtract(BigInteger.ONE));
		e = BigInteger.probablePrime(bitlen / 2, r);
		while (phi.gcd(e).compareTo(BigInteger.ONE) > 0 && e.compareTo(phi) < 0)
			e.add(BigInteger.ONE);
		d = e.modInverse(phi);
	}

	BigInteger encrypt(BigInteger message) {
		return message.modPow(e, n);
	}

	BigInteger decrypt(BigInteger encrypted) {
		return encrypted.modPow(d, n);
	}

	public static void main(String[] args) throws Exception {
		RSA rsa = new RSA();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the plain text:");
		String s = sc.nextLine();
		BigInteger message = new BigInteger(s);
		BigInteger encrpyted = rsa.encrypt(message);
		BigInteger decrptrd = rsa.decrypt(encrpyted);
		System.out.println("message: " + message);
		System.out.println("After encrption: " + encrpyted);
		System.out.println("After decrption: " + decrptrd);
		sc.close();
	}

}
