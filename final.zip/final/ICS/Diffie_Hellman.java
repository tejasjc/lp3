import java.util.*;

public class Diffie_Hellman {

	static int j, root;

	public boolean isPrime(int n) {
		if (n <= 1) {
			return false;
		}
		for (int i = 2; i < Math.sqrt(n); i++) {
			if (n % i == 0) {
				return false;
			}
		}
		return true;
	}

	public void findRoot() {

		TreeSet<Integer> t = new TreeSet<>();
		TreeSet<Integer> t1 = new TreeSet<>();
		Random r = new Random();
		for (int i = 0; i < 50; i++) {
			j = r.nextInt(50);
			if (isPrime(j))
				break;
		}
		for (int i = 1; i < j; i++) {
			t.add(i);
		}
		for (int i = 1; i < j; i++) {
			for (int k = 1; k < j; k++) {
				t1.add((int) ((Math.pow(i, k)) % j));
			}
			if (t.size() == t1.size()) {
				if (t1.containsAll(t)) {
					root = i;
					break;
				}
			}
			t1.removeAll(t);
		}
		System.out.println("p= " + j + "g= " + root);
	}

	public static void main(String args[]) {
		Diffie_Hellman m = new Diffie_Hellman();
		m.findRoot();
		int a = new Random().nextInt(10);
		int b = new Random().nextInt(100);

		int A = (int) Math.pow(root, a) % j;
		int B = (int) Math.pow(root, b) % j;

		int S_A = (int) Math.pow(B, a) % j;
		int S_B = (int) Math.pow(A, b) % j;

		System.out.println("Private Keys: " + a + " " + b);
		System.out.println("Public Keys: " + A + " " + B);
		System.out.println("Secret Key: " + S_A + " " + S_B);
		if (S_A == S_B) {
			System.out.println("ALice and Bob can communicate with each other!!!");
			System.out.println("They share a secret no = " + S_A);
		}

		else {
			System.out.println("ALice and Bob cannot communicate with each other!!!");
		}
	}
}
