from string import ascii_uppercase as letters
letters=letters.replace('J','')

def remove_repeated(string):
	charset=set()
	ans=[]
	for i in string:
		if i not in charset:
			ans.append(i)
		charset.add(i)
	return ''.join(ans)


def remove_punctuations(text):
	punctuations=['"',"'",'!','?',' ','.']
	for p in punctuations:
		text=text.replace(p,'')
	return text

def create_matrix(key):
	key.replace('J','I')
	key.replace('j','I')
	key=remove_repeated(key.upper()+letters)
	matrix=[list(key[i:i+5]) for i in range(0,25,5)]
	return matrix

def find_in_matrix(char,matrix):
	for i in range(5):
		for j in range(5):
			if matrix[i][j]==char:
				return i,j
				
def encrypt_pair(a,b,matrix):
	if a==b:
		b='X'

	r1,c1=find_in_matrix(a,matrix)
	r2,c2=find_in_matrix(b,matrix)

	if r1==r2:
		return matrix[r1][(c1+1)%5],matrix[r2][(c2+1)%5]
	elif c1==c2:
		return matrix[(r1+1)%5][c1],matrix[(r2+1)%5][c2]
	else:
		return matrix[r1][c2],matrix[r2][c1]

def decrypt_pair(a,b,matrix):
	
	r1,c1=find_in_matrix(a,matrix)
	r2,c2=find_in_matrix(b,matrix)

	if r1==r2:
		return matrix[r1][(c1-1)%5],matrix[r2][(c2-1)%5]
	elif c1==c2:
		return matrix[(r1-1)%5][c1],matrix[(r2-1)%5][c2]
	else:
		return matrix[r1][c2],matrix[r2][c1]

def encipher_text(key,text):
	matrix=create_matrix(key)
	text=remove_punctuations(text.upper())
	if len(text)%2 !=0:
		text = text + 'X'
	ans=[]
	for i in range(0,len(text),2):
			ans.extend(list(encrypt_pair(text[i],text[i+1],matrix)))

	return ''.join(ans)

def decipher_text(key,text):
	matrix=create_matrix(key)	
	ans=[]
	for i in range(0,len(text),2):
			ans.extend(list(decrypt_pair(text[i],text[i+1],matrix)))

	return ''.join(ans)

key=input("\nEnter key : ")
text=input("\nEnter plaintext : ")
cipher_text=encipher_text(key,text)
print("\nCipher Text :",cipher_text)
plain_text=decipher_text(key,cipher_text)
print("\nPlain Text :",plain_text)
