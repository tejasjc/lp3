package SAES;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Seas_algo {
//	static int plain_Text[]={1,1,0,1,0,1,1,1,0,0,1,0,1,0,0,0};
	static int plain_Text[]={0,1,1,0,1,1,1,1,0,1,1,0,1,0,1,1};
//	 static int key[]={0,1,0,0,1,0,1,0,1,1,1,1,0,1,0,1};
	 static int key[]={1,0,1,0,0,1,1,1,0,0,1,1,1,0,1,1};

	static int round_key[]={1,0,0,0,0,0,0,0};
	static int round_key2[]={0,0,1,1,0,0,0,0};
	static String gf_tab="0123456789abcdef";
	static byte mulTable[][] = {
	        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0,   0,   0,   0,   0,   0,   0},
	        {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0xa, 0xb, 0xc, 0xd, 0xe, 0xf}, 
	        {0, 2, 4, 6, 8, 0xa, 0xc, 0xe, 3, 1, 7, 5, 0xb, 9, 0xf, 0xd},
	        {0, 3, 6, 5, 0xc, 0xf, 0xa, 9, 0xb, 8, 0xd, 0xe, 7, 4, 1, 2},
	        {0, 4, 8, 0xc, 3, 7, 0xb, 0xf, 6, 2, 0xe, 0xa, 5, 1, 0xd, 9},
	        {0, 5, 0xa, 0xf, 7, 2, 0xd, 8, 0xe, 0xb, 4, 1, 9, 0xc, 3, 6},
	        {0, 6, 0xc, 0xa, 0xb, 0xd, 7, 1, 5, 3, 9, 0xf, 0xe, 8, 2, 4},
	        {0, 7, 0xe, 9, 0xf, 8, 1, 6, 0xd, 0xa, 3, 4, 2, 5, 0xc, 0xb},
	        {0, 8, 3, 0xb, 6, 0xe, 5, 0xd, 0xc, 4, 0xf, 7, 0xa, 2, 9, 1},
	        {0, 9, 1, 8, 2, 0xb, 3, 0xa, 4, 0xd, 5, 0xc, 6, 0xf, 7, 0xe},
	        {0, 0xa, 7, 0xd, 0xe, 4, 9, 3, 0xf, 5, 8, 2, 1, 0xb, 0xc, 6},
	        {0, 0xb, 5, 0xe, 0xa, 1, 0xf, 4, 7, 0xc, 2, 9, 0xd, 6, 8, 3},
	        {0, 0xc, 0xb, 7, 5, 9, 0xe, 2, 0xa, 6, 1, 0xd, 0xf, 3, 4, 8},
	        {0, 0xd, 9, 4, 1, 0xc, 8, 5, 2, 0xf, 0xb, 6, 3, 0x3, 0xa, 7},
	        {0, 0xe, 0xf, 1, 0xd, 3, 2, 0xc, 9, 7, 6, 8, 4, 0xa, 0xb, 5},
	        {0, 0xf, 0xd, 2, 9, 6, 4, 0xb, 1, 0xe, 0xc, 3, 8, 7, 5, 0xa}
	    };   
	Map<String, int[]> sbox = new HashMap<String, int[]>();
	static int k0[]=new int[16];
	static int k1[]=new int[16];
	static int k2[]=new int[16];
	public Seas_algo() {
		sbox.put("0000", new int[] {1,0,0,1});
		sbox.put("0001", new int[] {0,1,0,0});
		sbox.put("0010", new int[] {1,0,1,0});
		sbox.put("0011", new int[] {1,0,1,1});
		sbox.put("0100", new int[] {1,1,0,1});
		sbox.put("0101", new int[] {0,0,0,1});
		sbox.put("0110", new int[] {1,0,0,0});
		sbox.put("0111", new int[] {0,1,0,1});
		sbox.put("1000",new int[] {0,1,1,0});
		sbox.put("1001", new int[] {0,0,1,0});
		sbox.put("1010", new int[] {0,0,0,0});
		sbox.put("1011", new int[] {0,0,1,1});
		sbox.put("1100", new int[] {1,1,0,0});
		sbox.put("1101", new int[] {1,1,1,0});
		sbox.put("1110", new int[] {1,1,1,1});
		sbox.put("1111", new int[] {0,1,1,1});
	}
	
	//rotNib(): �rotate the nibbles�, which is equivalent to swapping the nibbles
	public int[] rotNib(int[] arr){
		int temp[]=new int[8];
		for(int x = 0; x <= arr.length-1; x++){
			  temp[(x+4) % arr.length ] = arr[x];
			}
		return temp;
	}
	
	
	public int[] getValue(int[] left_part) {
		String part1str = Arrays.toString(left_part);
		// part1str will have value in form of [1,0,1,1]... hence lets keep digits only
        part1str = part1str.replaceAll(", ", "").replace("[", "").replace("]", "");
        return sbox.get(part1str);
	}
	
	
	//SubNib() is �apply S-Box substitution on nibbles using encryption S-Box�
	public int[] subNib(int[] arr){
		//convert arr in two parts
		int[] left_part=new int[4];
		int[] right_part=new int[4];
        for (int i = 0; i < 4; i++) {
			left_part[i]=arr[i];
			right_part[i]=arr[i+4];
		}
        left_part=getValue(left_part);
        right_part=getValue(right_part);
        int[] result=new int[8];
        for (int i = 0; i < 4; i++) {
        	result[i]=left_part[i];
			result[i+4]=right_part[i];
		}
        return result;
        
	}
	public int[] subNib_round1(int[] arr){
		//convert arr in two parts
		int[] part1=new int[4];
		int[] part2=new int[4];
		int[] part3=new int[4];
		int[] part4=new int[4];
        for (int i = 0; i < 4; i++) {
			part1[i]=arr[i];
			part2[i]=arr[i+4];
			part3[i]=arr[i+8];
			part4[i]=arr[i+12];
		}
        part1=getValue(part1);
        part2=getValue(part2);
        part3=getValue(part3);
        part4=getValue(part4);
        int[] result=new int[16];
        //Swap 2nd nibble and 4th nibble
        for (int i = 0; i < 4; i++) {
        	result[i]=part1[i];
			result[i+4]=part4[i];
			result[i+8]=part3[i];
			result[i+12]=part2[i];
		}
        return result;
        
	}
	
	public int[] get_mul(int[] arr) {
		String part1str = Arrays.toString(arr);
        part1str = part1str.replaceAll(", ", "").replace("[", "").replace("]", "");
        String[] ans=Integer.toBinaryString(mulTable[gf_tab.indexOf("4")][gf_tab.indexOf(Integer.toString(Integer.parseInt(part1str,2),16))]).split("");
    	int[] temparr=new int[4];
    	
    	for (int i = 4-ans.length, j=0; j < ans.length; i++,j++) {
    		temparr[i]=Integer.parseInt(ans[j]);
    	}
    	return temparr;
	}
	public int [] mixCol(int[] arr) {
		int[] part1=new int[4];
		int[] part2=new int[4];
		int[] part3=new int[4];
		int[] part4=new int[4];
        for (int i = 0; i < 4; i++) {
			part1[i]=arr[i];
			part2[i]=arr[i+4];
			part3[i]=arr[i+8];
			part4[i]=arr[i+12];
		}
        int[] s00=new int[4];
		int[] s10=new int[4];
		int[] s01=new int[4];
		int[] s11=new int[4];
		int[] temp=get_mul(part2);
		for (int j = 0; j < 4; j++) {
			s00[j]=part1[j]^temp[j];
		}
		temp=get_mul(part4);
		for (int j = 0; j < 4; j++) {
			s01[j]=part3[j]^temp[j];
		}
		temp=get_mul(part1);
		for (int j = 0; j < 4; j++) {
			s10[j]=temp[j]^part2[j];
		}
		temp=get_mul(part3);
		for (int j = 0; j < 4; j++) {
			s11[j]=temp[j]^part4[j];
		}
		int[] result=new int[16];
        for (int i = 0; i < 4; i++) {
        	result[i]=s00[i];
			result[i+4]=s10[i];
			result[i+8]=s01[i];
			result[i+12]=s11[i];
		}
        return result;
	}
	public void genKey(){
		System.out.println("Plain Text :-"+Arrays.toString(plain_Text));

		int w0[]=new int[8];
		int w1[]=new int[8];
		int w2[]=new int[8];
		int w3[]=new int[8];
		int w4[]=new int[8];
		int w5[]=new int[8];
		//The input key is split into 2 words, w0 and w1
		for (int i = 0; i < 8; i++) {
			w0[i]=key[i];
			w1[i]=key[i+8];
		}
		//w0 XOR 10000000(round key)
		for (int j = 0; j < 8; j++) {
			w2[j]=w0[j]^round_key[j];
		}
		int subnib_temp[]=new int[8];
		subnib_temp=subNib(rotNib(w1));
		//w2 = w0 XOR 10000000 XOR SubNib(RotNib(w1))
		for (int j = 0; j < 8; j++) {
			w2[j]=w2[j]^subnib_temp[j];
		}
		//w3 = w2 XOR w1
		for (int j = 0; j < 8; j++) {
			w3[j]=w2[j]^w1[j];
		}
		//w4 = w2 XOR 0011 0000 XOR SubNib(RotNib(w3))
		for (int j = 0; j < 8; j++) {
			w4[j]=w2[j]^round_key2[j];
		}		
		subnib_temp=subNib(rotNib(w3));
		for (int j = 0; j < 8; j++) {
			w4[j]=w4[j]^subnib_temp[j];
		}
		//w5 = w4 XOR w3
		for (int j = 0; j < 8; j++) {
			w5[j]=w4[j]^w3[j];
		}
		
		
		//Key0 = w0w1
		for (int i = 0; i < 8; i++) {
			k0[i]=w0[i];
			k0[i+8]=w1[i];
		}
		//Key1 = w2w3
		for (int i = 0; i < 8; i++) {
			k1[i]=w2[i];
			k1[i+8]=w3[i];
		}
		//Key2 = w4w5
		for (int i = 0; i < 8; i++) {
			k2[i]=w4[i];
			k2[i+8]=w5[i];
		}
		System.out.println("Sub-keys are:");
		System.out.println("Key0:\t"+Arrays.toString(k0)+"\n"+"Key1:\t"+Arrays.toString(k1)+"\n"+"Key2:\t"+Arrays.toString(k2));
		
		
	}
	public void encrypt() {
		//Plaintext XOR Key0
		for (int i = 0; i < 16; i++) {
			plain_Text[i]=plain_Text[i]^k0[i];
		}
		//Round 1 Nibble Substitution (S-boxes) with plaintext
		plain_Text=subNib_round1(plain_Text);
		plain_Text=mixCol(plain_Text);
		for (int i = 0; i < 16; i++) {
			plain_Text[i]=plain_Text[i]^k1[i];
		}
		//final round
		plain_Text=subNib_round1(plain_Text);
		for (int i = 0; i < 16; i++) {
			plain_Text[i]=plain_Text[i]^k2[i];
		}
		System.out.println("Cipher Text :-"+Arrays.toString(plain_Text));
	}
	public static void main(String[] args) {
		Seas_algo obj=new Seas_algo();
		obj.genKey();
		obj.encrypt();
		
	}
	
}
