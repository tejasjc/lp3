import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier
from sklearn import tree
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn.model_selection import cross_val_score
import graphviz

columns=['Age','Income','Gender','Status']

cosmetic_data=pd.read_csv('dt.csv',sep=',',header=None)

#Label Encoding to convert categorical data to numeric data
le=preprocessing.LabelEncoder()
list1=[]
for i in range(4):
	cosmetic_data.values[::,i]=le.fit_transform(cosmetic_data.values[::,i])
	list1.append(le.classes_)

print("\n--------------------Encoded Data--------------------------------")

X=cosmetic_data.iloc[:,0:4].values
Y=cosmetic_data.iloc[:,4].values

print(X)
print(Y)

X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2,random_state=5)

dtc=DecisionTreeClassifier(criterion='entropy')
dtc.fit(X,Y)

print("\n-----Test Samples-----")
print("X_Test :",X_test)
y_predicted=dtc.predict(X_test)
print("Y_Predicted : ",y_predicted)

print("\nConfusion Matrix : ",confusion_matrix(Y_test,y_predicted))
print("\nAccuracy Score : ",accuracy_score(Y_test,y_predicted)*100)
print("\nClassification Report : \n",classification_report(Y_test,y_predicted))

age=list1[0].tolist().index('<21')
income=list1[1].tolist().index('Low')
gender=list1[2].tolist().index('Female')
status=list1[3].tolist().index('Married')

y_predicted=dtc.predict([[age,income,gender,status]])

print("\nPrediction for age < 21 , income=Low ,gender=Male , status=Married : ",y_predicted)

dot_data=tree.export_graphviz(dtc,out_file=None,feature_names=columns,class_names=['Yes','No'])
graph=graphviz.Source(dot_data)
graph.render("cos")

