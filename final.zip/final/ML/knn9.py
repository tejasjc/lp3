import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report,confusion_matrix
from sklearn.model_selection import train_test_split 
dataset=pd.read_csv("knn9.csv",names=['x','y','class'])

x=dataset.iloc[:,0:2].values 
y=dataset.iloc[:,2].values

X_train,X_test,Y_train,Y_test=train_test_split(x,y,test_size=0.2,random_state=2)


classifier=KNeighborsClassifier(n_neighbors=3)
classifier.fit(X_train,Y_train)

print("\nClass of the point [6,6] : ",classifier.predict([[6,6]]))
print("\nX_test :",X_test)
y_pred=classifier.predict(X_test)
print("\nY_pred : ",y_pred)

print(confusion_matrix(Y_test,y_pred))
print(classification_report(Y_test,y_pred))

error=[]
for i in range(1,5):
	kclass=KNeighborsClassifier(n_neighbors=i)
	kclass.fit(X_train,Y_train)
	pred_i=kclass.predict(X_test)
	error.append(np.mean(pred_i!=Y_test))

plt.figure(figsize=(12,16))
plt.plot(range(1,5),error,linestyle='dashed',color='red',linewidth=2,marker='o',markerfacecolor='blue',markersize=10)
plt.xlabel('K Value')
plt.ylabel('Mean Error')
plt.title('Error rate k value')
plt.show()
