import matplotlib.pyplot as plt  
import numpy as np  
from sklearn.cluster import KMeans
X = np.array([[1.0,1.0] , [1.5,2.0] ,[3.0,4.0] ,[5.0,7.0] ,[3.5,5.0] ,[4.5,5.0] ,[3.5,4.5]])
plt.scatter(X[:,0],X[:,1], label='True Position')  
kmeans = KMeans(n_clusters=2)  
kmeans.fit(X) 
print(kmeans.labels_)
plt.scatter(X[:,0], X[:,1], c=kmeans.labels_, cmap='rainbow')  
plt.scatter(kmeans.cluster_centers_[:,0] ,kmeans.cluster_centers_[:,1], color='black')
#What is updated value of m1 and m2?
print(kmeans.cluster_centers_) 
cost =[] 
X = np.array([[1.0,1.0] , [1.5,2.0] ,[3.0,4.0] ,[5.0,7.0] ,[3.5,5.0] ,[4.5,5.0] ,[3.5,4.5]])
for i in range(1, 8): 
    KM = KMeans(n_clusters = i) 
    KM.fit(X) 
      
    # calculates squared error 
    # for the clustered points 
    cost.append(KM.inertia_)      
  
#plot the cost against K values 
plt.plot(range(1, 8), cost, color ='g', linewidth ='3') 
plt.xlabel("Value of K") 
plt.ylabel("Sqaured Error (Cost)") 
plt.show() # clear the plot 
  
# the point of the elbow is the  
# most optimal value for choosing k 
#in this case k=3