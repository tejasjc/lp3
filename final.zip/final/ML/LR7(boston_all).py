import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_boston
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
from sklearn.metrics import accuracy_score
from sklearn.metrics import mean_squared_error 
from sklearn.model_selection import cross_val_score
boston_dataset=load_boston()
boston=pd.DataFrame(boston_dataset.data,columns=boston_dataset.feature_names)
boston['PRICE']=boston_dataset.target

x=boston.drop('PRICE',axis=1)
y=boston['PRICE']

X_train,X_test,Y_train,Y_test=train_test_split(x,y,test_size=0.2,random_state=5)

regressor=LinearRegression()
regressor.fit(X_train,Y_train)
m=regressor.coef_[0]
b=regressor.intercept_

print("\nSlope : ",m)
print("\nIntercept : ",b)

Y_pred=regressor.predict(X_test)

plt.scatter(Y_test,Y_pred)
plt.xlabel("Prices : $Y_i$")
plt.ylabel("Predicted Prices : $\hat{Y}_i$")
plt.title("Prices vs Predicted Prices:$Y_i$vs$\hat{Y}_i$")
plt.show()


print("\n\nModel Performance for training set")

rmse=(np.sqrt(mean_squared_error(Y_test,Y_pred)))
r2=r2_score(Y_test,Y_pred)
score=cross_val_score(regressor,X_train,Y_train,cv=5)
print("\nMean Sqaured Error : ",rmse)
print("\nR2 Score : ",r2)
print("\nCross Validation Score : ",score)


print("\n----------------------------------------------------------")
print("\n\tRidge Regression")

from sklearn.linear_model import Ridge
clf=Ridge(alpha=10)
clf.fit(X_train,Y_train)
y_pred=clf.predict(X_test)
print("\n\nModel Performance for Ridge")

rmse=(np.sqrt(mean_squared_error(Y_test,y_pred)))
r2=r2_score(Y_test,y_pred)
score=cross_val_score(regressor,X_train,Y_train,cv=5)
print("\nMean Sqaured Error : ",rmse)
print("\nR2 Score : ",r2)
print("\nCross Validation Score : ",score)


print("\n----------------------------------------------------------")

print("\n\tLasso Regression")

from sklearn.linear_model import Ridge
clf=Ridge(alpha=0.1)
clf.fit(X_train,Y_train)
y_pred=clf.predict(X_test)
print("\n\nModel Performance for Lasso")

rmse=(np.sqrt(mean_squared_error(Y_test,Y_pred)))
r2=r2_score(Y_test,Y_pred)
score=cross_val_score(regressor,X_train,Y_train,cv=5)
print("\nMean Sqaured Error : ",rmse)
print("\nR2 Score : ",r2)
print("\nCross Validation Score : ",score)


print("\n----------------------------------------------------------")

 

