
import matplotlib.pyplot as plt  
get_ipython().run_line_magic('matplotlib', 'inline')
import numpy as np  
from sklearn.cluster import KMeans
X = np.array([[0.1,0.6] , [0.15,0.71] ,[0.08,0.9] ,[0.16,
0.85] ,[0.2,0.3] ,[0.25,0.5] ,[0.24,0.1] ,[0.3,0.2]])
plt.scatter(X[:,0],X[:,1], label='True Position')  
kmeans = KMeans(n_clusters=2,init=np.array([[0.1,0.6],[0.3,0.2]]),n_init=1)  
kmeans.fit(X) 
print(kmeans.labels_)

#Which cluster does P6 belongs to?
print(kmeans.predict([[0.25,0.5]]))

#What is the population of cluster around m2?
from collections import Counter
print(Counter(kmeans.labels_))

plt.scatter(X[:,0], X[:,1], c=kmeans.labels_, cmap='rainbow')  
plt.scatter(kmeans.cluster_centers_[:,0] ,kmeans.cluster_centers_[:,1], color='black')
plt.show()
#What is updated value of m1 and m2?
print(kmeans.cluster_centers_) 

cost =[] 
X = np.array([[0.1,0.6] , [0.15,0.71] ,[0.08,0.9] ,[0.16,0.85] ,[0.2,0.3] ,[0.25,0.5] ,[0.24,0.1] ,[0.3,0.2]])
for i in range(1, 8): 
    KM = KMeans(n_clusters = i) 
    KM.fit(X) 
      
    # calculates squared error 
    # for the clustered points 
    cost.append(KM.inertia_)      
  
#plot the cost against K values 
plt.plot(range(1, 8), cost, color ='g', linewidth ='3') 
plt.xlabel("Value of K") 
plt.ylabel("Sqaured Error (Cost)") 
plt.show() # clear the plot  
# the point of the elbow is the  
# most optimal value for choosing k 
#in this case k=3





