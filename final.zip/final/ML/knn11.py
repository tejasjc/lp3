import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier
dataset=pd.read_csv("acid.csv",names=['x','y','class'])

x=dataset.iloc[:,0:2].values 
y=dataset.iloc[:,2].values

classifier=KNeighborsClassifier(n_neighbors=3)
classifier.fit(x,y)

y_pred=classifier.predict([[3,7]])

print("\nClass of the point [3,7] : ",y_pred)

error=[]
for i in range(1,4):
	kclass=KNeighborsClassifier(n_neighbors=i)
	kclass.fit(x,y)
	pred_i=kclass.predict(x)
	error.append(np.mean(pred_i!=y))

plt.figure(figsize=(12,16))
plt.plot(range(1,4),error,linestyle='dashed',color='red',linewidth=2,marker='o',markerfacecolor='blue',markersize=10)
plt.xlabel('K Value')
plt.ylabel('Mean Error')
plt.title('Error rate k value')
plt.show()
