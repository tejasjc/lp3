import numpy as np
from sklearn.datasets import load_boston
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

X=load_boston()['data']


cost=[]
for i in range(1,9):
	KM=KMeans(n_clusters=i)
	KM.fit(X)
	cost.append(KM.inertia_)

plt.plot(range(1,9),cost,color='g',linewidth=2)
plt.xlabel("Value of K")
plt.ylabel("Sum of Squared Distances")
plt.title("Elbow method to find optimal value of k")
plt.show()

k=int(input("\nEnter the optimal value of k observed from garph :"))

kmeans=KMeans(n_clusters=k,max_iter=500)
kmeans.fit(X)

plt.scatter(X[:,0],X[:,1],c=kmeans.labels_,cmap='rainbow')

centers=kmeans.cluster_centers_

plt.scatter(centers[:,0],centers[:,1],c='black',label='centroid',s=10,alpha=0.5)
plt.legend()
plt.show()
