import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_boston
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
from sklearn.metrics import accuracy_score
from sklearn.metrics import mean_squared_error 

boston_dataset=load_boston()
boston=pd.DataFrame(boston_dataset.data,columns=boston_dataset.feature_names)
boston['PRICE']=boston_dataset.target

x=boston.drop('PRICE',axis=1)
y=boston['PRICE']

x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=5)

regressor=LinearRegression()	
regressor.fit(x_train,y_train)
m=regressor.coef_
b=regressor.intercept_

print("\nSlope : ",m)
print("\nIntercept : ",b)
equation=[]
for i,coef in enumerate(m):
	equation.append('('+str(round(coef,2))+")*"+str(i+1))
	
print('Equation of best fit of line ' + ' + '.join(equation) + ' + (' + str(round(regressor.intercept_, 2)) + ')')

y_pred=regressor.predict(x_test)

plt.scatter(y_test,y_pred)
plt.xlabel("Prices : $Y_i$")
plt.ylabel("Predicted Prices : $\hat{Y}_i$")
plt.title("Prices vs Predicted Prices:$Y_i$vs$\hat{Y}_i$")
plt.show()


print("\n\nModel Performance for training set")
print("--------------------------------------------------------")

rmse=(np.sqrt(mean_squared_error(y_test,y_pred)))
r2_score=r2_score(y_test,y_pred)
print("\nMean Sqaured Error : ",rmse)
print("\nR2 Score : ",r2_score)
