import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

dataset=pd.read_csv("hours.csv")

x=dataset.iloc[:, :-1].values
y=dataset.iloc[:,1].values

regressor=LinearRegression()
regressor.fit(x,y)

print("Accuracy : ",regressor.score(x,y)*100)

y_pred=regressor.predict([[8]])

print("\nPredicted Value :",y_pred)

hours=int(input("\nENter the number of hours :"))

eq=regressor.coef_*hours+regressor.intercept_

print("y=%f*%f+%f"%(regressor.coef_,hours,regressor.intercept_))

print("\nRisk Score : ",eq[0])

plt.plot(x,y,'o')
plt.plot(x,regressor.predict(x))
plt.show()
